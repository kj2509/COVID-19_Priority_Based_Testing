package model;

public class Ministry extends Hospital{
public 	Ministry(){
		
	}
}
